# Logix_Zebra

Zebra Ethernet/IP Printer and Studio 5000 

Cf. https://www.plctalk.net/qanda/showthread.php?t=111789

N.B. the ZIP archive has everything

## Manifest

Zebra_Logix.zip

- The program and the PDF report


INV_Receptivo.ACD

- The program itself
  - Compact Logix, V30

Zebra ZT410 PLC Report.pdf

- Logix report of the program

README.md

- This file
